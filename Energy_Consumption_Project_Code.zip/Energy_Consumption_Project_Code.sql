-- Creating the main database to store global energy-related datasets
CREATE DATABASE EnergyConsumptionDB;

-- Using the energy database to create tables
USE EnergyConsumptionDB;

-- Creating Country table
CREATE TABLE Country (
    CID VARCHAR(10) PRIMARY KEY,
    Country VARCHAR(100) UNIQUE
);

-- Country Table's Structure
DESC Country;

-- Creating the Consumption table
CREATE TABLE Consumption (
    Country VARCHAR(100),
    Energy VARCHAR(50),
    Year INT,
    Consumption DOUBLE,
    FOREIGN KEY (Country) REFERENCES Country(Country)
);

-- Consumption Table's Structure
DESC Consumption;

-- Creating the Production table
CREATE TABLE Production (
    Country VARCHAR(100),
    Energy VARCHAR(50),
    Year INT,
    Production DOUBLE,
    FOREIGN KEY (Country) REFERENCES Country(Country)
);

-- Production Table's Structure
DESC Production;

-- Creating the Emission table
CREATE TABLE Emission (
    Country VARCHAR(100),
    Energy_Type VARCHAR(50),
    Year INT,
    Emission DOUBLE,
    Per_Capita_Emission DOUBLE,
    FOREIGN KEY (Country) REFERENCES Country(Country)
);

-- Emission Table's Structure
DESC Emission;

-- Creating the GDP table
CREATE TABLE GDP (
    Country VARCHAR(100),
    Year INT,
    Value DOUBLE,
    FOREIGN KEY (Country) REFERENCES Country(Country)
);

-- GDP Table's Structure
DESC GDP;

-- Creating the Population table
CREATE TABLE Population (
    Countries VARCHAR(100),
    Year INT,
    Value DOUBLE,
    FOREIGN KEY (Countries) REFERENCES Country(Country)
);

-- Population Table's Structure
DESC Population;

-- ------------------------------------------------------------------------------------------
-- General & Comparative Analysis
-- 1. What are the top 10 countries with the highest total emissions in the most recent year available?
SELECT Year, Country AS 'Country_Name', ROUND(SUM(Emission),3) AS 'Total_Emission'
FROM Emission
WHERE Year = (SELECT MAX(Year) FROM Emission)
GROUP BY Year, Country
ORDER BY Total_Emission DESC 
LIMIT 10;

-- 2. What are the top 5 countries by GDP in the most recent year? 
SELECT Year, Country AS 'Country_Name', Value AS 'GDP_Value'
FROM GDP
WHERE Year = (SELECT MAX(Year) FROM GDP)
ORDER BY GDP_Value DESC
LIMIT 5;

-- 3. Which countries have the highest energy deficit in the most recent year? 
WITH Total_Production_Tbl AS(
	SELECT Country, Year, SUM(Production) AS Total_Production
    FROM Production
    WHERE Year = (SELECT MAX(Year) FROM Production)
    GROUP BY Country, Year
),
Total_Consumption_Tbl AS(
	SELECT Country, Year, SUM(Consumption) AS Total_Consumption
    FROM Consumption
    WHERE Year = (SELECT MAX(Year) FROM Consumption)
    GROUP BY Country, Year
)

SELECT P.Country AS 'Country_Name', P.Year, ROUND((C.Total_Consumption - P.Total_Production),3) AS Energy_Deficit
FROM Total_Production_Tbl P
JOIN Total_Consumption_Tbl C ON C.Country = P.Country AND C.Year = P.Year
ORDER BY Energy_Deficit DESC
LIMIT 10;

-- 4. Which energy types contribute the most to total global emissions across all countries?
SELECT Energy_Type, ROUND(SUM(Emission),3) AS 'Total_Emission'
FROM Emission
GROUP BY Energy_Type
ORDER BY Total_Emission DESC;

-- -------------------------------------------------------------------------------------------------------------------------------------------------
-- Trend Analysis Over Time 
-- 5. How have global emissions changed year over year?
SELECT Year,ROUND(SUM(Emission),3) AS 'Total_Emission'
FROM Emission
GROUP BY YEAR
ORDER BY YEAR;

-- 6. What is the GDP trend over the years for the top 5 highest-GDP countries?
WITH Top3 AS (
    SELECT Country
    FROM GDP
    GROUP BY Country
    ORDER BY SUM(Value) DESC
    LIMIT 5
)
SELECT g.Country AS 'Country_Name', g.Year, g.Value AS 'GDP_Value'
FROM GDP g
JOIN Top3 t ON g.Country = t.Country
ORDER BY g.Country, g.Year;

-- 7. How has population growth affected total emissions over time for the top 5 most populated countries?
WITH Top5_Populated AS (
	SELECT Countries
    FROM Population
    GROUP BY Countries
    ORDER BY SUM(Value) DESC
    LIMIT 5
),
Pop AS (
    SELECT Countries AS Country, Year, SUM(Value) AS Total_Population
    FROM Population
    GROUP BY Countries, Year
),
Emi AS (
    SELECT Country, Year, SUM(Emission) AS Total_Emission
    FROM Emission
    GROUP BY Country, Year
)
SELECT p.Country AS 'Country_Name',
       p.Year,
       p.Total_Population,
       e.Total_Emission,
       ROUND(e.Total_Emission / p.Total_Population, 4) AS Emission_Per_Capita
FROM Pop p
JOIN Emi e ON p.Country = e.Country AND p.Year = e.Year
JOIN Top5_Populated t ON p.Country = t.Countries
ORDER BY p.Country, p.Year;
 
-- --------------------------------------------------------------------------------------------------------------------------------------
-- Ratio & Per Capita Analysis 
-- 8. Which 10 countries have the highest emission-to-GDP ratio in the most recent year?
WITH emi AS (
    SELECT Country, SUM(Emission) AS Total_Emission
    FROM Emission e
    WHERE Year = (SELECT MAX(year) FROM Emission)
    GROUP BY Country
),
gdp AS (
    SELECT Country, SUM(Value) AS Total_Gdp
    FROM GDP g
    WHERE Year = (SELECT MAX(year) FROM GDP)
    GROUP BY Country
)

SELECT e.Country, e.Total_Emission, g.Total_Gdp, ROUND(e.Total_Emission / g.Total_Gdp, 4) AS Emission_to_GDP_ratio
FROM emi e
JOIN gdp g ON e.Country = g.Country
ORDER BY Emission_to_GDP_ratio DESC
LIMIT 10;

-- 9. How does energy production per capita vary among the top 10 energy-producing nations?
WITH top10_prod AS (
    SELECT country
    FROM production
    GROUP BY country
    ORDER BY SUM(production) DESC
    LIMIT 10
),
prod AS (
    SELECT country, ROUND(SUM(production),3) AS total_production
    FROM production
    GROUP BY country
),
pop AS (
    SELECT countries AS country, ROUND(SUM(Value)) AS population
    FROM population
    GROUP BY countries
)
SELECT p.country,
       total_production,
       population,
       ROUND(total_production / population, 4) AS production_per_capita
FROM prod p
JOIN pop po ON p.country = po.country
JOIN top10_prod t ON p.country = t.country
ORDER BY production_per_capita DESC;

-- --------------------------------------------------------------------------------------------------------------------------------------
-- Global Comparisons
-- 10. Which are the top 10 most populated countries, and how do their total emissions compare
SELECT p.Countries AS 'Country_Name', p.Year, p.Value AS Population, ROUND(SUM(e.Emission),2) AS Total_Emission
FROM Population p
JOIN Emission e ON p.countries = e.country AND p.year = e.year
GROUP BY p.Countries, p.Year, p.Value
ORDER BY p.Value DESC
LIMIT 10;

-- 11. Which 10 countries have the highest energy consumption relative to their GDP
WITH g AS (
    SELECT Country, SUM(Value) AS Total_GDP
    FROM GDP
    GROUP BY Country
),
c AS (
    SELECT Country, SUM(Consumption) AS Total_Consumption
    FROM Consumption
    GROUP BY Country
)
SELECT g.Country, ROUND(c.Total_Consumption / g.Total_GDP, 4) AS Consumption_GDP_Ratio
FROM g
JOIN c ON g.Country = c.Country
ORDER BY Consumption_GDP_Ratio DESC
LIMIT 10;